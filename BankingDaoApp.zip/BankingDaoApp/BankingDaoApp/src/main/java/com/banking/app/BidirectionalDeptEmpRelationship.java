package com.banking.app;

import javax.persistence.EntityManager;

import com.banking.app.entity.Department;
import com.banking.app.entity.Employee;
import com.banking.app.util.EMUtils;

public class BidirectionalDeptEmpRelationship {

	public static void main(String[] args) {

		EntityManager em = EMUtils.provideEntityManager();
		//Get department & employee data from DB
		
		//Department dept = em.find(Department.class, 2);
		//System.out.println(dept.getDname());
		//dept.getEmps();
		//dept.getEmps().stream().forEach(System.out::println);
		
		Employee emp = em.find(Employee.class, 3);
		
		System.out.println(emp.getName());
		System.out.println(emp.getSalary());
		
		//System.out.println(emp.getDept().getDname());
		
		//Insert department & employee in DB
		/*Employee emp1 = new Employee();
		emp1.setName("Harish");
		emp1.setSalary(12000);
		
		Employee emp2 = new Employee();
		emp2.setName("Bhavesh");
		emp2.setSalary(7000);
		
		Department dept = new Department();
		dept.setDname("HR");
		dept.setDlocation("KKT");
		
		emp1.setDept(dept);
		emp2.setDept(dept);
		
		dept.getEmps().add(emp1);
		dept.getEmps().add(emp2);
		
		em.getTransaction().begin();
			em.persist(dept);
		em.getTransaction().commit();
		
		em.close();*/

	}

}
