package com.banking.app;

import java.util.Scanner;

import com.banking.app.dao.AccountDao;
import com.banking.app.dao.AccountDaoImpl;
import com.banking.app.entity.Account;

public class DepositeExample {

	public static void main(String[] args) {
		/*
		 * AccountDao dao = new AccountDaoImpl(); Account acc1 = new Account();
		 * acc1.setName("Ramesh"); acc1.setBalance(880);
		 * 
		 * if (dao.createAccount(acc1)) System.out.println("Account created.."); else
		 * System.out.println("Not created...");
		 */

		AccountDao dao = new AccountDaoImpl();
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter Account number");
		int ano = sc.nextInt();

		Account acc = dao.findAccountById(ano);

		if (acc == null)
			System.out.println("Account does not exist..");
		else {

			System.out.println("Enter the Amount to Deposit");
			int amt = sc.nextInt();

			acc.setBalance(acc.getBalance() + amt);

			if (dao.updateAccount(acc))
				System.out.println("Deposited Sucessfully...");
			else
				System.out.println("Technical Error .....");

		}

	}

}
